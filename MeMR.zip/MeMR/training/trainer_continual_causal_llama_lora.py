import os
import json
import math
import shutil
import numpy as np

import torch
import torch.nn as nn
from torch.optim import AdamW

from collections import defaultdict
from tqdm import tqdm

from transformers import GenerationConfig
from transformers.trainer_pt_utils import get_parameter_names
from transformers.optimization import get_scheduler
from training.early_stopping import EarlyStopping

from mpeft import get_peft_model
from mpeft.utils.save_and_load import set_peft_model_state_dict

from utils.compute_metrics import compute_metrics
from utils.utilities import mahalanobis

import time

class ContinualTrainerMTL(nn.Module):
    def __init__(self,
                 args,
                 model,
                 query_encoder,
                 logger,
                 task_list,
                 peft_config,
                 lora_save_dir,
                 label_list=None,
                 early_stopping_patience=-1,
                 tokenizer=None,
                 max_target_length=20,
                 learning_rate_list=None):
        super(ContinualTrainerMTL, self).__init__()
        
        self.args = args
        self.seed = args.seed
        self.model = model
        self.query_encoder = query_encoder.to(self.args.device)
        self.logger = logger
        self.task_list = task_list
        self.num_tasks = len(task_list)
        self.peft_config = peft_config
        
        self.num_train_epochs = math.ceil(args.num_train_epochs)
        self.early_stopping_patience = early_stopping_patience
        self.early_stopping = EarlyStopping(
            save_path=os.path.join(args.output_dir, 'best_checkpoint'),
            logger=self.logger,
            patience = early_stopping_patience
        )
        self.tokenizer = tokenizer
        self.max_target_length=max_target_length
        self.metric = 'rougeL'
        
        try:
            self.learning_rate_list = [float(x) for x in learning_rate_list.split('_')]
        except:
            self.learning_rate_list = [self.args.learning_rate for _ in range(self.num_tasks)]

        self.logger.info(f"***********************************seed: {self.seed}***********************************")
        self.logger.info(f"***********************************lr: {self.learning_rate_list}***********************************")
        self.logger.info(f"***********************************lr_scheduler_type: {self.args.lr_scheduler_type}***********************************")

    def _prepare_optimizer(self, task_id=None):
        decay_parameters = get_parameter_names(self.model, [nn.LayerNorm])
        decay_parameters = [name for name in decay_parameters if "bias" not in name]
        optimizer_grouped_parameters = [
            {
                "params": [p for n, p in self.model.named_parameters() if p.requires_grad and n in decay_parameters],
                "weight_decay": self.args.weight_decay,
            },
            {
                "params": [p for n, p in self.model.named_parameters() if p.requires_grad and n not in decay_parameters],
                "weight_decay": 0.0,
            },
        ]

        learning_rate = self.learning_rate_list[task_id] if self.learning_rate_list is not None else self.args.learning_rate
        optimizer_kwargs = {"lr": learning_rate, "betas": (self.args.adam_beta1, self.args.adam_beta2), "eps": self.args.adam_epsilon}
        self.optimizer = AdamW(optimizer_grouped_parameters, **optimizer_kwargs)
    
    def _prepare_scheduler(self, num_training_steps, optimizer):
        self.lr_scheduler = get_scheduler(
            self.args.lr_scheduler_type,
            optimizer=self.optimizer,
            num_warmup_steps=self.args.get_warmup_steps(num_training_steps),
            num_training_steps=num_training_steps,
        )

    def _process_data(self, loader, mode):
        try:
            data_batch = next(loader[1])
        except:
            loader[1] = iter(loader[0])
            data_batch = next(loader[1])
        
        data_batch = {k: v.to(self.args.device) if isinstance(v, torch.Tensor) else v for k, v in data_batch.items()}

        return data_batch

    def compute_loss(self, model, inputs, task, mode, query_embed=None, final=False):
        if mode == 'train':
            outputs = model(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                loss_mask=inputs["loss_mask"],
                labels=inputs["labels"],
                active_adapter=task,
                query_embed=query_embed,
                disentangle_modules=self.model.config.disentangle_modules,
                train=True,
                final=False,
            )
            return outputs
        else:
            generation_config = GenerationConfig(
                max_new_tokens=self.max_target_length,
                repetition_penalty=1.0,
                eos_token_id=self.tokenizer.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id,
                do_sample=False,
            )
            
            generated_tokens = model.generate(
                input_ids=inputs["input_ids"],
                active_adapter=task,
                query_embed=query_embed,
                disentangle_modules=self.model.config.disentangle_modules,
                generation_config=generation_config,
                train=False,
                final=final,
                attention_mask=inputs["attention_mask"],
            )
            return generated_tokens
    
    def _prepare_dataloaders(self, dataloaders):
        loader = {}
        batch_num = []
        for task in dataloaders.keys():
            loader[task] = [dataloaders[task], iter(dataloaders[task])]
            batch_num.append(len(dataloaders[task]))
        return loader, batch_num
    
    def _save_model_checkpoint_info(self, task, task_id, stage, save_dir="snapshots"):
        """在指定阶段保存模型的状态字典和元数据。"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        checkpoint_dir = os.path.join(self.args.output_dir, save_dir, f"task_{task_id}_{task}_{stage}_{timestamp}")
        os.makedirs(checkpoint_dir, exist_ok=True)

        state_dict_to_save = {}
        for k, v in self.model.state_dict().items():
            if 'key_encoder' in k or 'lora' in k or 'lm_head' in k:
                state_dict_to_save[k] = v.cpu().tolist()
        
        lora_adapters = list(self.model.peft_config.keys()) if hasattr(self.model, 'peft_config') else []
        lora_count = len(lora_adapters)
        
        key_encoder_info = {}
        if hasattr(self.model, 'key_encoder') and self.model.key_encoder is not None:
            keys = self.model.key_encoder.keys
            attn_weights_logs = []
            for weights in self.model.key_encoder.attn_weights:
                if weights is not None:
                    if isinstance(weights, torch.Tensor):
                        attn_weights_logs.append([round(w.item(), 4) for w in weights])
                    else: 
                        attn_weights_logs.append(weights)
                else:
                    attn_weights_logs.append(None)

            key_encoder_info = {
                'keys_shape': list(keys.shape),
                'keys_norm': round(keys.norm().item(), 4),
                'keys_mean': round(keys.mean().item(), 4),
                'is_orthogonal': torch.allclose(keys @ keys.T, torch.eye(keys.shape[0]).to(keys.device), atol=1e-4) if keys.shape[0] > 1 else True,
                'attn_weights': attn_weights_logs,
                'task_count': self.model.key_encoder.task_count,
            }
        
        checkpoint_info = {
            'task_id': task_id,
            'task_name': task,
            'stage': stage,
            'timestamp': timestamp,
            'lora_count': lora_count,
            'lora_adapters': lora_adapters,
            'key_encoder': key_encoder_info,
            'state_dict_keys': list(state_dict_to_save.keys()),
        }

        json_path = os.path.join(checkpoint_dir, 'checkpoint_info.json')
        with open(json_path, 'w') as f:
            json.dump(checkpoint_info, f, indent=2, ensure_ascii=False)

        torch.save(state_dict_to_save, os.path.join(checkpoint_dir, 'state_dict.pt'))
        self.logger.info(f"Saved checkpoint info for {task} at {stage} to {json_path}")
    
    def train(self, train_dataloaders, val_dataloaders, test_dataloaders):
        train_loader, train_batch = self._prepare_dataloaders(train_dataloaders)
        val_loader, val_batch = self._prepare_dataloaders(val_dataloaders)
        test_loader, test_batch = self._prepare_dataloaders(test_dataloaders)
        
        fwd_pass_results_metric = defaultdict(list)
        
        if self.args.do_train:
            for task_id, task in enumerate(self.task_list):
                if task_id == 0 or self.model.config.multi_peft_modules:
                    self.model = get_peft_model(self.model, self.peft_config, adapter_name=task)
                    self.model.print_trainable_parameters()
                self.model.set_adapter(adapter_name=task)

                num_train_batch = train_batch[task_id]
                len_dataloader = len(train_dataloaders[task])
                num_update_steps_per_epoch = max(len_dataloader // self.args.gradient_accumulation_steps, 1)
                num_training_steps_all_epochs = math.ceil(self.num_train_epochs * num_update_steps_per_epoch)
                
                self._prepare_optimizer(task_id)
                self._prepare_scheduler(num_training_steps_all_epochs, self.optimizer)
                self.model.epochs = self.num_train_epochs
                self.model.task_id = task_id
                self.early_stopping.reinit()
                eval_res = defaultdict(list)

                self.logger.info(f"***** 开始训练 - 任务 {task_id}: {task} *****")
                self.logger.info(f"  总轮次 (Num Epochs) = {self.num_train_epochs}")
                self.logger.info(f"  单设备批大小 (Batch size per device) = {self.args.per_device_train_batch_size}")
                self.logger.info(f"  梯度累积步数 (Gradient Accumulation steps) = {self.args.gradient_accumulation_steps}")
                self.logger.info(f"  总优化步数 (Total optimization steps) = {num_training_steps_all_epochs}")

                for epoch in range(self.num_train_epochs):
                    self.model.epoch = epoch
                    self.model.train()

                    self.model.zero_grad()

                    for batch_index in tqdm(range(num_train_batch), desc=f"轮次 {epoch+1}/{self.num_train_epochs}"):
                        train_input = self._process_data(train_loader[task], mode='train')

                        query_embed = self._get_query_embed(train_input)
                        
                        outputs = self.compute_loss(self.model, train_input, task, mode='train', query_embed=query_embed)
                        train_loss = outputs.loss if isinstance(outputs, dict) else outputs[0]
                        train_loss = train_loss / self.args.gradient_accumulation_steps
                        
                        train_loss.backward()
                        if (batch_index + 1) % self.args.gradient_accumulation_steps == 0:
                            self.optimizer.step()
                            self.lr_scheduler.step()
                            self.optimizer.zero_grad()
                    eval_res_ = self.eval(val_loader[task], val_batch[task_id], task, mode='val')
                    for k, v in eval_res_.items():
                        eval_res[k].append(v)
                    
                    self.clean_gpu_memory()
                    es_task_name = task if self.model.config.multi_peft_modules else self.task_list[0]
                    
                    if self.early_stopping_patience > 0 and self.early_stopping(eval_res_[self.metric], self.model, es_task_name) :
                        best_metric_eval = self.early_stopping.best_score
                        best_epoch = eval_res[self.metric].index(best_metric_eval)
                        self.logger.info(f"触发早停！任务 [{task}] 的最佳轮次为: {best_epoch+1}")
                        self.logger.info(f"最佳验证集 {self.metric} 分数 [{task}]: {round(best_metric_eval, 4)}")

                        set_peft_model_state_dict(self.model, self.early_stopping.best_model, adapter_name=es_task_name)
                        break
                    
                best_res_test = self.eval(test_loader[task], test_batch[task_id], task, mode='test')
                self.logger.info(f"任务 [{task}] 训练后的测试结果:")
                for k, v in best_res_test.items():
                    self.logger.info(f"  {k}: {round(v, 4)}")
                    if k == self.metric:
                        fwd_pass_results_metric[k].append(v)

                # Save model state at test end
                self._save_model_checkpoint_info(task, task_id, stage="test_end")

                if self.model.config.multi_peft_modules and not self.model.config.disentangle_modules and hasattr(self.model, 'key_encoder'):
                    self.model.key_encoder.process_task_count()
        
        self.logger.info(f"---------- 所有任务的最终评估 ----------")
        test_results_metric = defaultdict(list)
        for t_id, t in enumerate(self.task_list):
            self.logger.info(f"--- 评估任务 [{t}] ---")
            test_res = self.eval(test_loader[t], test_batch[t_id], t, mode='test', final=True)
            for k, v in test_res.items():
                test_results_metric[k].append(v)
        
        for k in test_results_metric.keys():
            self._log_final_results(test_loader, test_results_metric[k], fwd_pass_results_metric.get(k), key=k)
            
        shutil.rmtree(self.early_stopping.save_path)

    def _get_query_embed(self, model_inputs):
        if self.query_encoder is None:
            return None
        input_ids = model_inputs['query_input_ids']
        attention_mask = model_inputs['query_attention_mask']
        with torch.no_grad():
            hidden_states = self.query_encoder(input_ids, attention_mask=attention_mask)[0]
        
        if self.model.config.query_encoder_type == 'avg_all_embed':
            return hidden_states.mean(dim=1)
        elif self.model.config.query_encoder_type == 'avg_word_embed':
            masked_sum = torch.sum(hidden_states * attention_mask.unsqueeze(-1), dim=1)
            num_tokens = torch.sum(attention_mask, dim=1).unsqueeze(-1)
            return masked_sum / (num_tokens + 1e-9)
        return None
    
    def eval(self, loader, batch, task, mode='test', final=False):
        self.model.eval()
        results = defaultdict(list)
        with torch.no_grad():
            for _ in tqdm(range(batch), desc=f"评估 {task} ({mode})"):
                input_data = self._process_data(loader, mode)

                query_embed = self._get_query_embed(input_data)
                generated_tokens = self.compute_loss(self.model, input_data, task, mode=mode, query_embed=query_embed, final=final)
                references = input_data["targets"]
                input_len = input_data["input_ids"].shape[1]
                predictions = self._postprocess_generated_tokens(generated_tokens, input_len)
                decoded_references = self.tokenizer.batch_decode(references, skip_special_tokens=True, clean_up_tokenization_spaces=True)
                
                metrics = compute_metrics(predictions, decoded_references)
                for key, value in metrics.items():
                    results[key].append(value)
        
        if final:
            self.logger.info(f"***** 任务 {task} - 最终评估: {mode} *****")
        else:
            self.logger.info(f"***** 任务 {task} - 轮次 {self.model.epoch+1}: {mode} (seed {self.seed}) *****")
        
        avg_results = {}
        for key, value in results.items(): 
            avg_value = round(sum(value)/len(value), 4)
            avg_results[key] = avg_value
            self.logger.info(f"  {key}: {avg_value}")
        
        return avg_results
    def _postprocess_generated_tokens(self, generated_tokens, input_length):
        if isinstance(generated_tokens, torch.Tensor):
            generated_tokens = generated_tokens.cpu().numpy()
        generated_part = generated_tokens[:, input_length:]
        generated_part = np.where(generated_part == -100, self.tokenizer.pad_token_id, generated_part)
        
        predictions = self.tokenizer.batch_decode(
            generated_part, 
            skip_special_tokens=True, 
            clean_up_tokenization_spaces=True
        )
        return [pred.strip() for pred in predictions]

    def _log_final_results(self, test_loader, test_results, fwd_pass_results=None, key='rougeL'):
        self.logger.info(f"********************** 最终 {key.upper()} 结果 (seed: {self.seed}) **********************")
        
        task_names = list(test_loader.keys())
        self.logger.info(f"任务顺序: {task_names}")

        if fwd_pass_results:
            self.logger.info(f"即时测试 {key}: {fwd_pass_results}")
            avg_fwd = round(sum(fwd_pass_results)/len(fwd_pass_results), 4)
            self.logger.info(f"平均即时测试 {key}: {avg_fwd}")
        
        self.logger.info(f"最终测试 {key} (所有训练后): {test_results}")
        avg_final = round(sum(test_results)/len(test_results), 4)
        self.logger.info(f"平均最终测试 {key}: {avg_final}")
        self.logger.info("******************************************************************")

    def clean_gpu_memory(self):
        torch.cuda.empty_cache()
    