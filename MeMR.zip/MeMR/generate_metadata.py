import json
import torch
from transformers import LlamaTokenizer, LlamaModel, BitsAndBytesConfig
import os
import numpy as np

# 元数据JSON文件的路径
# 请确保您的merged_metadata.json文件位于这个路径下
METADATA_JSON_PATH = "./metadata_embeddings/merged_metadata.json"
META_EMBEDDINGS_SAVE_PATH = "./metadata_embeddings/keshi_meta_embeddings_1.pt"

TASK_LIST_ORDER_PINYIN = ["neike", "waike", "erke", "fuchanke", "nanke", "zhongliuke"]

LLAMA_MODEL_PATH = "chinese-alpaca-plus-7b-hf"
PINYIN_TO_CHINESE_MAP = {
    "neike": "内科",
    "waike": "外科",
    "erke": "儿科",
    "fuchanke": "妇产科",
    "nanke": "男科",
    "zhongliuke": "肿瘤科",
}


print(f"Loading Llama Tokenizer and Model from: {LLAMA_MODEL_PATH}")

tokenizer = LlamaTokenizer.from_pretrained(LLAMA_MODEL_PATH, add_prefix_space=True)

tokenizer.bos_token_id = 1
tokenizer.eos_token_id = 2
tokenizer.pad_token_id = 1

compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
quantization_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=compute_dtype,
)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = LlamaModel.from_pretrained(
    LLAMA_MODEL_PATH,
    quantization_config=quantization_config,
    device_map="auto",
    torch_dtype=compute_dtype,
    trust_remote_code=True
)

for param in model.parameters():
    param.requires_grad = False
model.eval()

KEY_DIM = model.config.hidden_size
print(f"LlamaModel loaded. Embedding dimension (key_dim): {KEY_DIM}")
print(f"Ensure that KeyEncoderConfig.key_dim is set to {KEY_DIM} in your training script.")


print(f"Loading metadata from: {METADATA_JSON_PATH}")
if not os.path.exists(METADATA_JSON_PATH):
    raise FileNotFoundError(f"Metadata JSON file not found at {METADATA_JSON_PATH}")

with open(METADATA_JSON_PATH, 'r', encoding='utf-8') as f:
    loaded_data_list = json.load(f)
    full_metadata_dict = {item['department']: item for item in loaded_data_list}

all_meta_embeddings = []
num_processed_tasks = 0

print("Processing and encoding metadata for each department...")
for pinyin_task_name in TASK_LIST_ORDER_PINYIN:
    chinese_task_name = PINYIN_TO_CHINESE_MAP.get(pinyin_task_name)
    if chinese_task_name is None:
        raise ValueError(f"No Chinese mapping found for pinyin task name: '{pinyin_task_name}'. "
                         f"Please update PINYIN_TO_CHINESE_MAP in the script.")

    if chinese_task_name not in full_metadata_dict:
        raise ValueError(f"Metadata for task '{chinese_task_name}' (pinyin: '{pinyin_task_name}') "
                         f"is missing in the JSON file at '{METADATA_JSON_PATH}'. "
                         f"Please ensure all tasks in PINYIN_TO_CHINESE_MAP are present in the JSON.")
        
    metadata = full_metadata_dict[chinese_task_name]
    
    keywords_str = "。关键词：" + "，".join(metadata['keywords']) if metadata.get('keywords') else ""
    symptoms_str = "。症状：" + "，".join(metadata['symptoms']) if metadata.get('symptoms') else ""
    
    text_to_encode = f"{metadata['description']}{keywords_str}{symptoms_str}"
    
    print(f"  Encoding '{chinese_task_name}' (pinyin: '{pinyin_task_name}'): {text_to_encode[:100]}...")

    inputs = tokenizer(
        text_to_encode, 
        return_tensors="pt", 
        padding='longest', 
        truncation=True, 
        max_length=2048,
        add_special_tokens=True 
    )
    inputs = {k: v.to(device) for k, v in inputs.items()}
    
    with torch.no_grad():
        outputs = model(**inputs)
        last_hidden_state = outputs.last_hidden_state
        attention_mask = inputs['attention_mask']

        masked_embeddings = last_hidden_state * attention_mask.unsqueeze(-1) 
        sum_embeddings = torch.sum(masked_embeddings, dim=1) 
        num_tokens = torch.sum(attention_mask, dim=1).unsqueeze(-1) 
        
        mean_pooling_embeddings = sum_embeddings / torch.clamp(num_tokens, min=1e-9)
    
    if mean_pooling_embeddings.shape[1] != KEY_DIM:
        raise ValueError(f"Embedding dimension mismatch for task '{chinese_task_name}'. "
                         f"Expected {KEY_DIM}, got {mean_pooling_embeddings.shape[1]}. Check LlamaModel config.")
    
    all_meta_embeddings.append(mean_pooling_embeddings.squeeze(0).cpu())

    num_processed_tasks += 1

if num_processed_tasks != len(TASK_LIST_ORDER_PINYIN):
    print(f"Error: Number of processed tasks ({num_processed_tasks}) does not match expected tasks in order list ({len(TASK_LIST_ORDER_PINYIN)}).")
    exit()

final_meta_embeddings = torch.stack(all_meta_embeddings)
print(f"Successfully generated final meta embeddings with shape: {final_meta_embeddings.shape}")

os.makedirs(os.path.dirname(META_EMBEDDINGS_SAVE_PATH), exist_ok=True)
torch.save(final_meta_embeddings, META_EMBEDDINGS_SAVE_PATH)
print(f"Meta embeddings saved to: {META_EMBEDDINGS_SAVE_PATH}")
