
import os
from datasets import load_dataset, Dataset
import torch
from torch.utils.data import DataLoader
from transformers import default_data_collator, DataCollatorWithPadding

PROMPT_TEMPLATE = "你是一位专业的AI医生，请根据患者的提问给出建议。\n\n患者提问：{instruction}\n\nAI医生回答："


def custom_data_collator(features, tokenizer):
    targets_list = [f.pop("targets", None) for f in features]
    data_collator = DataCollatorWithPadding(tokenizer, pad_to_multiple_of=8)
    batch = data_collator(features)
    batch['targets'] = targets_list

    if "loss_mask" in features[0] and isinstance(features[0]["loss_mask"], list):
         loss_masks = [f["loss_mask"] for f in features]
         batch['loss_mask'] = torch.tensor(loss_masks, dtype=torch.long)

    return batch


def preprocess_function(examples, tokenizer, max_seq_length, is_eval=False):

    instructions = examples['instruction']
    outputs = examples['output']
    
    sources = []
    targets = []


    for instruction, output in zip(instructions, outputs):
        source = PROMPT_TEMPLATE.format(instruction=instruction)
        target = f" {output}{tokenizer.eos_token}"
        sources.append(source)
        targets.append(target)

    tokenized_sources = tokenizer(sources, add_special_tokens=False)
    tokenized_targets = tokenizer(targets, add_special_tokens=False)

    all_input_ids = []
    all_loss_masks = []
    all_labels_for_eval = [] 
    all_padded_labels = [] 
    all_query_input_ids = [] 
    all_query_attention_masks = [] 

    for source_ids, target_ids in zip(tokenized_sources['input_ids'], tokenized_targets['input_ids']):
        if is_eval:
            input_ids = [tokenizer.bos_token_id] + source_ids
            labels = target_ids
        else:
            input_ids = [tokenizer.bos_token_id] + source_ids + target_ids
            labels = input_ids
        
        source_len = len(source_ids) + 1
        loss_mask = [0] * source_len + [1] * len(target_ids) if not is_eval else [0] * len(input_ids)
        
        if len(input_ids) > max_seq_length:
            input_ids = input_ids[:max_seq_length]
            loss_mask = loss_mask[:max_seq_length]
        else:
            padding_length = max_seq_length - len(input_ids)
            input_ids = [tokenizer.pad_token_id] * padding_length + input_ids
            loss_mask = [0] * padding_length + loss_mask
            
        if len(labels) > max_seq_length:
            labels = labels[:max_seq_length]
        else:
            padding_length = max_seq_length - len(labels)
            labels = [tokenizer.pad_token_id] * padding_length + labels
        
        all_input_ids.append(input_ids)
        all_loss_masks.append(loss_mask)
        all_labels_for_eval.append(target_ids)
        all_padded_labels.append(labels)

        query_ids = [tokenizer.bos_token_id] + source_ids
        if len(query_ids) > max_seq_length:
            query_ids = query_ids[:max_seq_length]
        else:
            padding_length = max_seq_length - len(query_ids)
            query_ids = [tokenizer.pad_token_id] * padding_length + query_ids
        
        query_attention_mask = [0 if token_id == tokenizer.pad_token_id else 1 for token_id in query_ids]
        
        all_query_input_ids.append(query_ids)
        all_query_attention_masks.append(query_attention_mask)

    model_inputs = {
        'input_ids': torch.tensor(all_input_ids, dtype=torch.long),
        'attention_mask': torch.tensor(
            [[0] * sum(1 for x in ids if x == tokenizer.pad_token_id) + [1] * (len(ids) - sum(1 for x in ids if x == tokenizer.pad_token_id)) for ids in all_input_ids],
            dtype=torch.long
        ),
        'labels': torch.tensor(all_padded_labels, dtype=torch.long),
        'loss_mask': torch.tensor(all_loss_masks, dtype=torch.long),
        'targets': all_labels_for_eval,
        'query_input_ids': torch.tensor(all_query_input_ids, dtype=torch.long),
        'query_attention_mask': torch.tensor(all_query_attention_masks, dtype=torch.long),
    }

    return model_inputs


def DataLoaderMTL(
    data_args,
    training_args,
    task_list,
    tokenizer,
    max_seq_length=None,
    overwrite_cache=False,
):

    dataset_root_dir = "datasets/medical_consult"

    validation_split_percentage = data_args.validation_split_percentage if hasattr(data_args, 'validation_split_percentage') else 0.1

    dataloaders = {}

    tokenizer.padding_side = 'left'
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    custom_collator_fn = lambda features: custom_data_collator(features, tokenizer)

    for task in task_list:
        print(f"--- Processing task: {task} ---")
        
        train_file_path = os.path.join(dataset_root_dir, task, 'train.json')
        if not os.path.exists(train_file_path):
            raise FileNotFoundError(f"Data file not found for task '{task}' at path: {train_file_path}")

        raw_dataset = load_dataset('json', data_files=train_file_path, split='train')

        split_dataset = raw_dataset.train_test_split(test_size=validation_split_percentage, seed=training_args.seed)
        train_dataset = split_dataset['train']
        eval_dataset = split_dataset['test']
        print(f"Task '{task}': {len(train_dataset)} training samples, {len(eval_dataset)} validation samples.")

        train_dataset = train_dataset.map(
            lambda examples: preprocess_function(examples, tokenizer, max_seq_length, is_eval=False),
            batched=True,
            remove_columns=raw_dataset.column_names,
            load_from_cache_file=not overwrite_cache,
            desc=f"Running tokenizer on {task} train dataset",
        )
        
        eval_dataset = eval_dataset.map(
            lambda examples: preprocess_function(examples, tokenizer, max_seq_length, is_eval=True),
            batched=True,
            remove_columns=raw_dataset.column_names,
            load_from_cache_file=not overwrite_cache,
            desc=f"Running tokenizer on {task} eval dataset",
        )

        # 创建 DataLoader
        dataloaders[task] = {
            'train': DataLoader(
                train_dataset,
                batch_size=training_args.per_device_train_batch_size, 
                sampler=torch.utils.data.RandomSampler(train_dataset),
                collate_fn=custom_collator_fn, 
                drop_last=training_args.dataloader_drop_last,   
                num_workers=training_args.dataloader_num_workers,
                pin_memory=training_args.dataloader_pin_memory, 
            ),
            'dev': DataLoader(
                eval_dataset,
                batch_size=training_args.per_device_eval_batch_size,
                sampler=torch.utils.data.SequentialSampler(eval_dataset),
                collate_fn=custom_collator_fn,
                drop_last=False,
                num_workers=training_args.dataloader_num_workers,
                pin_memory=training_args.dataloader_pin_memory,
            )
        }
        
    print("--- All dataloaders created successfully! ---")
    return dataloaders