import os
import sys
sys.path.append(".")
sys.path.append("../")
current_script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_script_dir)
sys.path.insert(0, project_root)

import nltk
import numpy as np
from evaluate import load

import json
from transformers import LlamaTokenizer, HfArgumentParser, TrainingArguments, set_seed, AutoConfig
from mpeft import LoraConfig, KeyEncoderConfig, TaskType
from arguments import DataTrainingArguments, ModelArguments
import torch

from transformers import BitsAndBytesConfig, LlamaModel

from utils.set_logger import set_logger
from model.causal_lm_llama import LlamaContinualForCausalLM
from training.trainer_continual_causal_llama_lora import ContinualTrainerMTL
from tasks.mtl5.dataloader_mtl_causal_llama import DataLoaderMTL

if __name__ == "__main__":
    
    parser = HfArgumentParser((TrainingArguments, DataTrainingArguments, ModelArguments))
    training_args, data_args, model_args = parser.parse_args_into_dataclasses()
    
    seed = training_args.seed
    set_seed(seed)
    
    if not os.path.exists(training_args.output_dir):
        os.makedirs(training_args.output_dir, exist_ok=True)
    lora_output_dir = os.path.join(training_args.output_dir, 'lora')
    if not os.path.exists(lora_output_dir):
        os.mkdir(lora_output_dir)
    
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM, r=4, lora_alpha=16, lora_dropout=0.1, bias="none", 
        output_dir=lora_output_dir,
        target_modules=[
            "q_proj",
            "v_proj",
        ],
        mpeft_enabled=model_args.mpeft_enabled,
        )
    
    logfile = os.path.join(training_args.output_dir, "log.txt")
    logger = set_logger(logfile)
    
    config_path = os.path.join(training_args.output_dir, f"configs.json")
    with open(config_path, "a", newline='\n') as f:
        f.write(f"\n(m)peft_args:\n {peft_config}\n")
        f.write(f"\ntraining_args:\n {training_args}\n")

    task_list = data_args.task_list.split('_')
    
    model_name_or_path = model_args.model_name_or_path
    tokenizer = LlamaTokenizer.from_pretrained(model_name_or_path,
                                            add_prefix_space=True,
                                            padding_side='left',  # 左填充
                                            trust_remote_code=True  # 支持某些自定义模型的tokenizer
                                            )
    tokenizer.bos_token_id = 1
    tokenizer.eos_token_id = 2
    tokenizer.pad_token_id = 1
    
    if data_args.max_seq_length_list is not None:
        max_seq_length = [int(sql) for sql in data_args.max_seq_length_list.split('_')]
    else:
        max_seq_length = data_args.max_seq_length
    max_target_length = data_args.max_target_length

    compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    logger.info(f"Using compute dtype: {compute_dtype}")

    quantization_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=compute_dtype,
    )
    logger.info(f"Using quantization config: {quantization_config}")

    dataloaders = DataLoaderMTL(
        data_args=data_args,
        training_args=training_args,
        task_list=task_list,
        tokenizer=tokenizer,
        max_seq_length=max_seq_length,
        overwrite_cache=data_args.overwrite_cache,
    )
    train_dataloaders = {task: dataloaders[task]['train'] for task in task_list}
    dev_dataloaders = {task: dataloaders[task]['dev'] for task in task_list}
    test_dataloaders = {task: dataloaders[task]['dev'] for task in task_list}
    
    
    """
    model = LlamaContinualForCausalLM.from_pretrained(
        pretrained_model_name_or_path=model_name_or_path,
        device_map="auto",
        offload_folder="offload",
        trust_remote_code=True
        )
    """
    model = LlamaContinualForCausalLM.from_pretrained(
        pretrained_model_name_or_path=model_name_or_path,
        quantization_config=quantization_config,
        device_map="auto",
        offload_folder="offload",
        trust_remote_code=True,
    )
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    
    for arg in dir(model_args):
        if not arg.startswith("__") and not callable(getattr(model_args, arg)):
            setattr(model.config, arg, getattr(model_args, arg))

    """
    query_encoder = LlamaModel(model.config)
    for param in query_encoder.parameters():
        param.requires_grad = False
    """
    query_encoder = None
    if model_args.mpeft_enabled:
        logger.info(f"Loading query encoder (LlamaModel) from {model_name_or_path} with quantization...")
        try:
            query_encoder = LlamaModel.from_pretrained(
                model_name_or_path,
                quantization_config=quantization_config,
                device_map="auto",                      
                offload_folder="offload_query",         
                torch_dtype=compute_dtype,              
                trust_remote_code=True
            )

            for param in query_encoder.parameters():
                param.requires_grad = False
            logger.info("Froze query encoder parameters.")

        except Exception as e:
            logger.error(f"Failed to load quantized query encoder (LlamaModel): {e}")
            raise e
    else:
        logger.info("MPEFT not enabled, skipping query encoder loading.")
    if model_args.mpeft_enabled:
        mpeft_config = KeyEncoderConfig(
            seed=seed,
            query_encoder_type=model_args.query_encoder_type,
            task_list=data_args.task_list.split('_'),
            meta_embeddings_path=model_args.meta_embeddings_path,
            key_dim=model.config.hidden_size,
            )
        peft_config.mpeft_config = mpeft_config
        with open(config_path, "a", newline='\n') as f:
            f.write(f"\n(m)peft_args_after_model_init:\n {peft_config}\n")

    trainer = ContinualTrainerMTL(
        args=training_args,
        model=model,
        query_encoder=query_encoder,
        logger=logger,
        task_list=task_list,
        label_list=None,
        peft_config=peft_config,
        lora_save_dir=os.path.join(training_args.output_dir, 'checkpoint_loras'),
        early_stopping_patience=data_args.early_stopping_patience if data_args.early_stop else -1,
        tokenizer=tokenizer,
        max_target_length = data_args.max_target_length,
        learning_rate_list=data_args.learning_rate_list,
    )
    
    trainer.train(
        train_dataloaders,
        dev_dataloaders,
        test_dataloaders,
    )