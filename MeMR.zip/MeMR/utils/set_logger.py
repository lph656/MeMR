import logging

def set_logger(logfile):
    logger = logging.getLogger()
    
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler(filename=logfile, encoding="utf-8", mode="a")
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s")
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger