

import os
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from tensorboardX import SummaryWriter

class DynamicAttentionLayer(nn.Module):
    def __init__(self, key_dim):
        super().__init__()
        self.key_dim = key_dim
        
    def forward(self, E_query, V_meta_k, E_task_k):
        # E_query: [batch_size, key_dim] (问诊编码)
        # V_meta_k: [num_tasks, key_dim] (所有科室的元数据向量，静态)
        # E_task_k: [num_tasks, key_dim] (可训练的科室嵌入)

        device = E_task_k.device
        target_dtype = E_task_k.dtype

        E_query = E_query.to(device).to(target_dtype)
        V_meta_k = V_meta_k.to(device).to(target_dtype)
        E_task_k = E_task_k.to(device).to(target_dtype) 

        norm_query = nn.functional.normalize(E_query, dim=-1)
        norm_meta_k = nn.functional.normalize(V_meta_k, dim=-1)

        attn_scores = torch.einsum('bd,td->bt', norm_query, norm_meta_k) 
        
        alpha_k = torch.sigmoid(attn_scores)
        
        alpha_k_expanded = alpha_k.unsqueeze(-1)

        E_task_k_expanded = E_task_k.unsqueeze(0).expand(E_query.shape[0], -1, -1)
        V_meta_k_expanded = V_meta_k.unsqueeze(0).expand(E_query.shape[0], -1, -1)

        E_dynamic_k = alpha_k_expanded * V_meta_k_expanded + (1 - alpha_k_expanded) * E_task_k_expanded
        
        return E_dynamic_k # [batch_size, num_tasks, key_dim]

class TaskKeyEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        
        self.config = config
        self.seed = config.seed
        
        self.task_list = config.task_list
        self.num_tasks = len(self.task_list)
        self.task_count = 0

        self.steps = {t_id: 0 for t_id in range(self.num_tasks)}
        self.steps_val = {t_id: 0 for t_id in range(self.num_tasks)}
        self.steps_final = {t_id: 0 for t_id in range(self.num_tasks)}
        
        if self.config.meta_embeddings_path is None:
            raise ValueError("config.meta_embeddings_path must be provided for MDTM initialization and dynamic matching.")
        if not os.path.exists(self.config.meta_embeddings_path):
            raise FileNotFoundError(f"Metadata embeddings file not found at {self.config.meta_embeddings_path}")
        
        self.all_meta_keys = torch.load(self.config.meta_embeddings_path).to(device='cuda')
        assert self.all_meta_keys.shape[0] == self.num_tasks, \
            f"Loaded meta_embeddings count {self.all_meta_keys.shape[0]} does not match num_tasks {self.num_tasks}."
        assert self.all_meta_keys.shape[1] == self.config.key_dim, \
            f"Loaded meta_embeddings dim {self.all_meta_keys.shape[1]} does not match config.key_dim {self.config.key_dim}."
        print(f"Loaded {self.num_tasks} metadata embeddings from {self.config.meta_embeddings_path} with dim {self.config.key_dim}")
        self.dynamic_attn_layer = DynamicAttentionLayer(self.config.key_dim)
        
        self.key_ortho_threshold = getattr(config, 'key_ortho_threshold', 0.1)
        self.lamda_keys_L2 = getattr(config, 'lamda_keys_L2', 0.005)
        print(f"TaskKeyEncoder - Key Ortho Threshold: {self.key_ortho_threshold}, Key L2 Lambda: {self.lamda_keys_L2}")

        self._initialize_keys()
        
        if hasattr(self.config, 'bnb_4bit_compute_dtype') and self.config.bnb_4bit_compute_dtype is not None:
             self.keys.data = self.keys.data.to(self.config.bnb_4bit_compute_dtype)
             self.all_meta_keys = self.all_meta_keys.to(self.config.bnb_4bit_compute_dtype)
             print(f"TaskKeyEncoder keys and meta_keys converted to {self.config.bnb_4bit_compute_dtype}")
        
        self.log_weights = True
        tb_log_dir = os.path.join(self.config.output_dir, f"tensorboard_seed{self.seed}")
        if not os.path.exists(tb_log_dir):
            os.makedirs(tb_log_dir, exist_ok=True)
        self.writer = SummaryWriter(log_dir=tb_log_dir)
        

    def forward(self, x_query, adapter_name, train=True, final=False):
        task_id = self.task_list.index(adapter_name)
        
        if train and not final:
            self.steps[task_id] += 1
        elif not train and not final:
            self.steps_val[task_id] += 1
        else:
            self.steps_final[task_id] += 1
        
        batch_size = x_query.shape[0]
        loss = torch.tensor(0., requires_grad=True, device='cuda')
        
        K_meta = self.all_meta_keys[:task_id+1] 
        K_task = self.keys[:task_id+1]         
        
        E_dynamic_k = self.dynamic_attn_layer(x_query, K_meta, K_task)
        n_q = nn.functional.normalize(x_query.to(E_dynamic_k.dtype), dim=-1).detach().unsqueeze(1) 
        n_dynamic_k = nn.functional.normalize(E_dynamic_k, dim=-1)

        cos_sim = torch.bmm(n_q, n_dynamic_k.transpose(1, 2)).squeeze(1)
        for i in range(cos_sim.shape[-1]): 
            if i < len(self.keys_mask) and self.keys_mask[i]: 
                cos_sim = cos_sim.clone()
                cos_sim[:, i] = -1e8

        w = nn.functional.softmax(cos_sim*self.config.softmax_match_scale, dim=-1) if not self.config.direct_compose else cos_sim
        
        if train:
            loss, ortho_loss_key, matching_loss, l2_loss_keys = self._add_kp_losses(K_task, w, cos_sim, loss, batch_size, task_id, x_query)
        
        if not train and not final:
            w_avg = torch.mean(w.detach().clone(), dim=0)
            if self.attn_weights[task_id] is None:
                self.attn_weights[task_id] = w_avg
            else:
                self.attn_weights[task_id] = ((self.attn_weights[task_id] * self.steps_val[task_id]) + w_avg) / (self.steps_val[task_id]+1)
        
        self._log_weights(w, task_id, train, final)
                    
        if train:
            self._log_losses(task_id, ortho_loss_key, matching_loss, l2_loss_keys)
            
        return w, loss

    def _initialize_keys(self):
        self.attn_weights = [None for _ in range(self.num_tasks)]
        
        self.keys = nn.Parameter(self.all_meta_keys.clone().detach(), requires_grad=True) 
        print(f"Task keys (E_task_k) initialized from loaded metadata embeddings.")

        self.keys_mask = [False for _ in range(self.num_tasks)]
        
        if self.config.key_init_func == 'uniform':
            print("Uniform initialization skipped as metadata init is used.")
        
        elif self.config.key_init_func == 'orthogonal':
            print("Task keys (E_task_k) initialized from metadata embeddings. Hard orthogonalization at init is SKIPPED.")
            self.ortho_loss_key = True
        else:
            self.ortho_loss_key = getattr(self.config, 'ortho_loss_key', False)

        self.ortho_loss_coeff = self.config.ortho_loss_coeff
        

    def _add_kp_losses(self, K_task_for_loss, w, cos_sim, loss, batch_size, task_id, x_query):
        ortho_loss_key = 0
        if self.ortho_loss_key:
            ortho_loss_key_val = self.ortho_loss_coeff * self.ortho_penalty(K_task_for_loss)
            loss = loss + ortho_loss_key_val 
            ortho_loss_key = ortho_loss_key_val.item()

        l2_loss_keys = 0
        if self.lamda_keys_L2 > 0:
            l2_loss_keys_val = self.lamda_keys_L2 * torch.norm(self.keys, p=2) 
            loss = loss + l2_loss_keys_val
            l2_loss_keys = l2_loss_keys_val.item()

        matching_loss = 0
        if self.config.matching_loss:
            matching_loss_val = (1.0-w[:, -1]).mean() * self.config.matching_loss_coeff
            loss = loss + matching_loss_val
            matching_loss = matching_loss_val.item()

        if self.config.matching_loss_v2:
            matching_loss_val = (1.0-cos_sim[:, -1]).mean() * self.config.matching_loss_coeff
            loss = loss + matching_loss_val
            matching_loss = matching_loss_val.item()

        if self.config.matching_loss_cls:
            gt_w = torch.zeros_like(w, device=w.device)
            gt_w[:, task_id] = 1.
            gt_w = gt_w[:, :cos_sim.shape[-1]]

            matching_loss_val = torch.abs(gt_w - w).mean() * self.config.matching_loss_coeff
            loss = loss + matching_loss_val
            matching_loss = matching_loss_val.item()

        if self.config.matching_loss_cls_all:
            gt_w = torch.zeros_like(w, device=w.device)
            gt_w[:, task_id] = 1.

            matching_loss_val = torch.abs(gt_w - w).mean() * self.config.matching_loss_coeff
            loss = loss + matching_loss_val
            matching_loss = matching_loss_val.item()
        

        return loss, ortho_loss_key, matching_loss, l2_loss_keys
   
    def _log_weights(self, w, task_id, train, final):
        if self.log_weights:
            w_avg = torch.mean(w.detach().clone(), dim=0)
            
            for t in range(w_avg.shape[-1]):
                if train and not final:
                    step = self.steps[task_id]
                    log_name = f'training_weight_{task_id}/{t}'
                elif not train and not final:
                    step = self.steps_val[task_id]
                    log_name = f'validation_weight_{task_id}/{t}'
                elif final:
                    step = self.steps_final[task_id]
                    log_name = f'final_weight_{task_id}/{t}'

                self.writer.add_scalar(log_name, w_avg[t], step)

    def _log_losses(self, task_id, ortho_loss_key, matching_loss, l2_loss_keys):
        if self.ortho_loss_key and not isinstance(ortho_loss_key, (tuple, list)): 
            self.writer.add_scalar(f'ortho_loss/task_{task_id}', ortho_loss_key, self.steps[task_id])
        if self.config.matching_loss or self.config.matching_loss_v2 or self.config.matching_loss_cls or self.config.matching_loss_cls_all:
            self.writer.add_scalar(f'matching_loss/task_{task_id}', matching_loss, self.steps[task_id])
        if self.lamda_keys_L2 > 0:
            self.writer.add_scalar(f'l2_keys_loss/task_{task_id}', l2_loss_keys, self.steps[task_id])    
    
    def gram_schmidt(self, vv):
        def projection(u, v):
            denominator = (u * u).sum()

            if denominator < 1e-8:
                return None
            else:
                return (v * u).sum() / denominator * u
        
        is_nd = len(vv.shape) > 2
        if is_nd:
            shape_nd = copy.deepcopy(vv.shape)
            vv = vv.view(vv.shape[0], -1)
            
        vv = vv.T

        nk = vv.size(1)
        uu = torch.zeros_like(vv, device=vv.device)
        
        s = self.task_count
        if s>0:
            uu[:, 0:s] = vv[:, 0:s].clone()
            
        for k in range(s, nk):
            redo = True
            while redo:
                redo = False
                vk = torch.randn_like(vv[:,k]).to(vv.device)
                uk = 0
                for j in range(0, k):
                    if not redo:
                        uj = uu[:, j].clone()
                        proj = projection(uj, vk)
                        if proj is None:
                            redo = True
                            print('restarting!')
                        else:
                            uk = uk + proj
                if not redo:
                    uu[:, k] = vk - uk
                    
        for k in range(s, nk):
            uk = uu[:, k].clone()
            uu[:, k] = uk / uk.norm()
            
        uu = uu.T 
        
        if is_nd:
            uu = uu.view(shape_nd)
        
        return nn.Parameter(uu) 
    
    
    def ortho_penalty(self, t):
        if t.shape[0] == 1:
            return torch.tensor(0.0, device=t.device, dtype=t.dtype)

        gram_matrix = t @ t.T 
        
        off_diagonal_elements = gram_matrix - torch.eye(t.shape[0], dtype=t.dtype, device=t.device)
        mask = ~torch.eye(t.shape[0], dtype=torch.bool, device=t.device)
        
        abs_off_diagonal = torch.abs(off_diagonal_elements[mask])
        
        if self.key_ortho_threshold > 0:
            penalty = F.relu(abs_off_diagonal - self.key_ortho_threshold).mean()
        else:
            penalty = abs_off_diagonal.mean()
        
        return penalty
    
    def process_task_count(self):
        self.task_count += 1
        
        if self.config.key_init_func == 'orthogonal':
            print(f"Task keys (E_task_k) NOT hard orthogonalized after adding task {self.task_count-1}.")
