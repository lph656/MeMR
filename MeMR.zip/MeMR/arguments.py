"""
A cleaned and simplified configuration file for the medical continual learning project.
Unused arguments from the original classification task have been removed for clarity.
"""

from dataclasses import dataclass, field
from typing import Optional
from transformers import HfArgumentParser, TrainingArguments


@dataclass
class DataTrainingArguments:
    """
    Arguments pertaining to what data we are going to input our model for training and eval.
    """
    task_list: str = field(
        default='neike_waike_erke_fuchanke_nanke_zhongliuke',
        metadata={"help": "Task list for continual learning, order matters."}
    )
    
    validation_split_percentage: float = field(
        default=0.1,
        metadata={"help": "The percentage of the train set to be used as a validation set."}
    )
    max_seq_length: int = field(
        default=1024,
        metadata={"help": "The maximum total input sequence length after tokenization."}
    )
    
    max_seq_length_list: Optional[str] = field(
        default=None,
        metadata={
            "help": "A string of task-specific max sequence lengths, separated by underscores (e.g., '512_256_512'). "
            "If provided, this will override the global max_seq_length for each task."
        }
    )

    max_target_length: int = field(
        default=512,
        metadata={"help": "The maximum target sequence length for generation."}
    )


    padding_strategy: str = field(
        default="longest",
        metadata={"help": "Padding strategy. Choices: ['max_length', 'longest', 'do_not_pad']"}
    )
    overwrite_cache: bool = field(
        default=False, metadata={"help": "Overwrite the cached preprocessed datasets or not."}
    )
    early_stop: bool = field(
        default=True, metadata={"help": "Use early stopping or not."}
    )
    early_stopping_patience: Optional[int] = field(
        default=5,
        metadata={"help": "Patience for early stopping."}
    )
    learning_rate_list: Optional[str] = field(
        default=None,
        metadata={"help": "Use a different learning rate for each task, separated by '_'."}
    )
    
    pad_to_max_length: bool = field(
        default=False,
        metadata={"help": "Legacy argument. 'padding_strategy' is preferred."}
    )
    add_dataset_name: bool = field(
        default=False, metadata={"help": "Legacy argument. Not used in the current dataloader."}
    )


@dataclass
class ModelArguments:
    """
    Arguments pertaining to which model/config/tokenizer we are going to fine-tune from.
    """
    model_name_or_path: str = field(
        default="chinese-alpaca-plus-7b-hf",
        metadata={"help": "Path to pretrained model or model identifier from huggingface.co/models"}
    )
    meta_embeddings_path: Optional[str] = field(
        default=None,
        metadata={"help": "Path to the pre-encoded metadata embeddings (.pt file) for task key initialization and dynamic matching."}
    )
    mpeft_enabled: bool = field(
        default=True,
        metadata={"help": "Enable 'mixture of peft modules' functionalities."}
    )
    continual_learning: bool = field(
        default=True,
        metadata={"help": "Run in the continual learning mode."}
    )
    query_encoder_type: str = field(
        default="avg_word_embed",
        metadata={"help": "Embedding type for query encoder. Options: 'avg_all_embed', 'avg_word_embed'."}
    )
    matching_loss_v2: bool = field(
        default=True,
        metadata={"help": "Enable query <-> key matching loss."}
    )
    matching_loss_coeff: float = field(
        default=1.0,
        metadata={"help": "Coefficient for the matching loss term."}
    )

    multi_peft_modules: bool = field(
        default=True,
        metadata={
            "help": "Multi-task learning with multiple prefix (for composition / concatenation / identification)"
        }
    )
    
    disentangle_modules: bool = field(
        default=False,
        metadata={"help": "Used for per-task fine-tuning and EPI inference (an alternative CL strategy)."}
    )
    task_identify_epi: bool = field(
        default=False,
        metadata={"help": "Select module based on Gaussian distribution prototypes during inference (EPI strategy)."}
    )
    
    hidden_dropout_prob: float = field(
        default=0.1,
        metadata={"help": "The dropout probability used in the models."}
    )
    cache_dir: Optional[str] = field(
        default=None,
        metadata={"help": "Where to store the pretrained models downloaded from huggingface.co"},
    )
    model_revision: str = field(
        default="main",
        metadata={"help": "The specific model version to use."},
    )